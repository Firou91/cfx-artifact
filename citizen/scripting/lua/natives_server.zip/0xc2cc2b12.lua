--- Gets the vertical bounds of a polygon collision shape.
-- @param colShapeId The collision shape ID.
-- @param minZ Lower Z bound output.
-- @param maxZ Upper Z bound output.
-- @return Returns true if the data was retrieved successfully. Returns false if the ID is invalid or the shape is of a different type.
function Global.GetColshapePolygonData(colShapeId)
	return _in(0xcd8bfe8d, colShapeId, _f, _f, _r)
end
