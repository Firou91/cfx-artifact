--- Gets the data of a sphere collision shape.
-- @param colShapeId The collision shape ID.
-- @param x Center X coordinate output.
-- @param y Center Y coordinate output.
-- @param z Center Z coordinate output.
-- @param radius Sphere radius output.
-- @return Returns true if the data was retrieved successfully. Returns false if the ID is invalid or the shape is of a different type.
function Global.GetColshapeSphereData(colShapeId)
	return _in(0xff94c6db, colShapeId, _f, _f, _f, _f, _r)
end
