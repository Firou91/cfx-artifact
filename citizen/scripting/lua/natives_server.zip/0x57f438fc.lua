--- GET_VEHICLE_BODY_HEALTH
function Global.GetVehicleBodyHealth(vehicle)
	return _in(0x2b2fcc28, vehicle, _rf)
end
