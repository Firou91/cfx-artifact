--- Creates a rotated rectangle collision shape at the specified 3D position.
-- When an entity enters or leaves a collision shape, the `onColshapeEnter` and `onColshapeExit` events are triggered. Both events are called with the entity handle that triggered them and the collision shape ID.
-- @param x Center X coordinate.
-- @param y Center Y coordinate.
-- @param z Center Z coordinate.
-- @param width Total width.
-- @param depth Total depth.
-- @param heading Rotation heading in radians.
-- @return The collision shape ID, or -1 on failure.
function Global.CreateColshapeRectangle(x, y, z, width, depth, heading)
	return _in(0x58c3f669, x, y, z, width, depth, heading, _ri)
end
