--- Gets the data of a rectangle collision shape.
-- @param colShapeId The collision shape ID.
-- @param x Center X coordinate output.
-- @param y Center Y coordinate output.
-- @param z Center Z coordinate output.
-- @param width Width output.
-- @param depth Depth output.
-- @param heading Heading output in radians.
-- @return Returns true if the data was retrieved successfully. Returns false if the ID is invalid or the shape is of a different type.
function Global.GetColshapeRectangleData(colShapeId)
	return _in(0xed8b05df, colShapeId, _f, _f, _f, _f, _f, _f, _r)
end
