--- GET_PLAYER_GUID
function Global.GetPlayerGuid(playerSrc)
	return _in(0xe52d9680, _ts(playerSrc), _s)
end
