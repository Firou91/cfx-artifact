--- Creates a polygon collision shape defined by a set of 2D points extruded between `minZ` and `maxZ`. Requires at least 3 points.
-- When an entity enters or leaves a collision shape, the `onColshapeEnter` and `onColshapeExit` events are triggered. Both events are called with the entity handle that triggered them and the collision shape ID.
-- @param minZ Minimum Z height of the polygon.
-- @param maxZ Maximum Z height of the polygon.
-- @param points An array of interleaved x, y point pairs (e.g., `{x1, y1, x2, y2, x3, y3, ...}`). Must contain at least 3 pairs.
-- @return The collision shape ID, or -1 on failure.
function Global.CreateColshapePolygon(minZ, maxZ, points)
	local points_bytes, points_len = _obj(points)
	return _in(0x1b055f04, minZ, maxZ, points_bytes, points_len, _ri)
end
