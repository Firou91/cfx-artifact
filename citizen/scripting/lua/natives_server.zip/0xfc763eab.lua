--- Returns whether the given 3D point is inside the collision shape.
-- @param colShapeId The collision shape ID.
-- @param x Point X coordinate.
-- @param y Point Y coordinate.
-- @param z Point Z coordinate.
-- @return Returns true if the point is inside the collision shape, false otherwise.
function Global.IsPointInsideColshape(colShapeId, x, y, z)
	return _in(0x324dcfa6, colShapeId, x, y, z, _r)
end
