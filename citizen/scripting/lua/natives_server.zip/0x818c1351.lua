--- SET_CONVAR_SERVER_INFO
function Global.SetConvarServerInfo(varName, value)
	return _in(0x9338d547, _ts(varName), _ts(value))
end
