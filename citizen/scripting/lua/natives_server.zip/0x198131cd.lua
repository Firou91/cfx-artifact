--- GET_VEHICLE_TOTAL_REPAIRS
-- @return Returns the total amount of repairs. Each repair will increase the count to make it possible to detect client repairs.
-- 		The value has a range from 0 to 15. Next value after 15 is 0.
function Global.GetVehicleTotalRepairs(vehicle)
	return _in(0x9963d5f9, vehicle, _ri)
end
