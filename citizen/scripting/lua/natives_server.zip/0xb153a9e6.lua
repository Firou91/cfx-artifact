--- Gets the data of a circle collision shape.
-- @param colShapeId The collision shape ID.
-- @param x Center X coordinate output.
-- @param y Center Y coordinate output.
-- @param radius Circle radius output.
-- @return Returns true if the data was retrieved successfully. Returns false if the ID is invalid or the shape is of a different type.
function Global.GetColshapeCircleData(colShapeId)
	return _in(0x1dc0d547, colShapeId, _f, _f, _f, _r)
end
