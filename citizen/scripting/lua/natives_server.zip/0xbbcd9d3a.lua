--- Returns whether the collision shape with the given ID is a sphere.
-- @param colShapeId The collision shape ID.
-- @return Returns true if the collision shape exists and is a sphere, false otherwise.
function Global.IsColshapeSphere(colShapeId)
	return _in(0xc53e0758, colShapeId, _r)
end
