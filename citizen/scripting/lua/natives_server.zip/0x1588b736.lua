--- GET_IS_VEHICLE_SECONDARY_COLOUR_CUSTOM
function Global.GetIsVehicleSecondaryColourCustom(vehicle)
	return _in(0x288ad228, vehicle, _r)
end
