--- Creates a spherical collision shape at the specified 3D position.
-- When an entity enters or leaves a collision shape, the `onColshapeEnter` and `onColshapeExit` events are triggered. Both events are called with the entity handle that triggered them and the collision shape ID.
-- @param x Center X coordinate.
-- @param y Center Y coordinate.
-- @param z Center Z coordinate.
-- @param radius Sphere radius.
-- @return The collision shape ID, or -1 on failure.
function Global.CreateColshapeSphere(x, y, z, radius)
	return _in(0xb6710acb, x, y, z, radius, _ri)
end
