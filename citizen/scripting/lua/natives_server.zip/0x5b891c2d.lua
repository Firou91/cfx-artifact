--- Returns whether the collision shape with the given ID is a rectangle.
-- @param colShapeId The collision shape ID.
-- @return Returns true if the collision shape exists and is a rectangle, false otherwise.
function Global.IsColshapeRectangle(colShapeId)
	return _in(0xae0f25ea, colShapeId, _r)
end
