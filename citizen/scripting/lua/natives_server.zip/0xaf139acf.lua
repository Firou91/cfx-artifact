--- Returns whether a collision shape with the given ID exists.
-- @param colShapeId The collision shape ID.
-- @return Returns true if the collision shape exists, false otherwise.
function Global.DoesColshapeExist(colShapeId)
	return _in(0x9a2ec46d, colShapeId, _r)
end
