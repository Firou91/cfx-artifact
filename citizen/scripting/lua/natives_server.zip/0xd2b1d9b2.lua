--- Gets the data of a cuboid collision shape.
-- @param colShapeId The collision shape ID.
-- @param x Center X coordinate output.
-- @param y Center Y coordinate output.
-- @param z Center Z coordinate output.
-- @param width Width output.
-- @param depth Depth output.
-- @param height Height output.
-- @return Returns true if the data was retrieved successfully. Returns false if the ID is invalid or the shape is of a different type.
function Global.GetColshapeCuboidData(colShapeId)
	return _in(0x9d0bc07c, colShapeId, _f, _f, _f, _f, _f, _f, _r)
end
