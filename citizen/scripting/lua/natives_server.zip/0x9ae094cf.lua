--- Creates a 2D circular collision shape at the specified position.
-- @param x Center X coordinate.
-- @param y Center Y coordinate.
-- @param radius Circle radius.
-- @return The collision shape ID, or -1 on failure.
function Global.CreateColshapeCircle(x, y, radius)
	return _in(0xb9c5ac6d, x, y, radius, _ri)
end
