--- Creates a vertical cylinder collision shape at the specified 3D position.
-- @param x Center X coordinate.
-- @param y Center Y coordinate.
-- @param z Center Z coordinate.
-- @param radius Cylinder radius.
-- @param height Total height.
-- @return The collision shape ID, or -1 on failure.
function Global.CreateColshapeCylinder(x, y, z, radius, height)
	return _in(0x59ad59ac, x, y, z, radius, height, _ri)
end
