--- Returns whether the collision shape with the given ID is a circle.
-- @param colShapeId The collision shape ID.
-- @return Returns true if the collision shape exists and is a circle, false otherwise.
function Global.IsColshapeCircle(colShapeId)
	return _in(0xaaeb581a, colShapeId, _r)
end
