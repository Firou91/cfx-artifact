--- Deletes the collision shape with the given ID.
-- @param colShapeId The collision shape ID.
function Global.DeleteColshape(colShapeId)
	return _in(0x16b9f12b, colShapeId)
end
