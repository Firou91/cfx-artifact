--- Returns whether the collision shape with the given ID is a cuboid.
-- @param colShapeId The collision shape ID.
-- @return Returns true if the collision shape exists and is a cuboid, false otherwise.
function Global.IsColshapeCuboid(colShapeId)
	return _in(0x80a7b8df, colShapeId, _r)
end
