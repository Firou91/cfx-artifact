--- Creates an axis-aligned box collision shape at the specified 3D position.
-- @param x Center X coordinate.
-- @param y Center Y coordinate.
-- @param z Center Z coordinate.
-- @param width Total width.
-- @param depth Total depth.
-- @param height Total height.
-- @return The collision shape ID, or -1 on failure.
function Global.CreateColshapeCuboid(x, y, z, width, depth, height)
	return _in(0x79ae8777, x, y, z, width, depth, height, _ri)
end
