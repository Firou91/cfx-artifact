--- Returns whether the collision shape with the given ID is a polygon.
-- @param colShapeId The collision shape ID.
-- @return Returns true if the collision shape exists and is a polygon, false otherwise.
function Global.IsColshapePolygon(colShapeId)
	return _in(0x91e01b1e, colShapeId, _r)
end
