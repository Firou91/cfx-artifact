--- Gets the data of a cylinder collision shape.
-- @param colShapeId The collision shape ID.
-- @param x Center X coordinate output.
-- @param y Center Y coordinate output.
-- @param z Center Z coordinate output.
-- @param radius Cylinder radius output.
-- @param height Height output.
-- @return Returns true if the data was retrieved successfully. Returns false if the ID is invalid or the shape is of a different type.
function Global.GetColshapeCylinderData(colShapeId)
	return _in(0x83b79cda, colShapeId, _f, _f, _f, _f, _f, _r)
end
