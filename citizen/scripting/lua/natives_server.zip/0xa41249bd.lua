--- Returns whether the collision shape is set to detect the given entity type. Every type is enabled by default; a type reads as disabled only after `SET_COLSHAPE_ENTITY_TYPE(colShapeId, entityType, false)`.
-- @param colShapeId The collision shape ID.
-- @param entityType The sync (network) entity type index (e.g. GTA5: automobile `0`, object `5`, ped `6`, player `11`). See `SET_COLSHAPE_ENTITY_TYPE` for the full per-game tables.
-- @return Returns true if the entity type is detected by the collision shape, false otherwise.
function Global.IsColshapeEntityTypeSet(colShapeId, entityType)
	return _in(0xb5b22c62, colShapeId, entityType, _r)
end
