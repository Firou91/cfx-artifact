--- Returns whether the collision shape with the given ID is a cylinder.
-- @param colShapeId The collision shape ID.
-- @return Returns true if the collision shape exists and is a cylinder, false otherwise.
function Global.IsColshapeCylinder(colShapeId)
	return _in(0xa9cc9f3d, colShapeId, _r)
end
